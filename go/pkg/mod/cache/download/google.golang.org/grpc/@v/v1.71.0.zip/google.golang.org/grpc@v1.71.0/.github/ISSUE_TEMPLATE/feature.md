---
name: Feature Request
about: Suggest an idea for gRPC-Go
labels: 'Type: Feature'

---

Please see the FAQ in our main README.md before submitting your issue.

### Use case(s) - what problem will this feature solve?

### Proposed Solution

### Alternatives Considered

### Additional Context
