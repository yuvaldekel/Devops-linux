![logo-png](logo.png)

Package memory implements a memory allocator.

## Build status

available at https://modern-c.appspot.com/-/builder/?importpath=modernc.org%2fmemory

Installation

    $ go get modernc.org/memory

[![Go Reference](https://pkg.go.dev/badge/modernc.org/memory.0.svg)](https://pkg.go.dev/modernc.org/memory)
