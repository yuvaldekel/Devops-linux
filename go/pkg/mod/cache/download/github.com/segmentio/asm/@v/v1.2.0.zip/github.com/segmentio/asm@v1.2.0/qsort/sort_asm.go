//go:build !purego && amd64
// +build !purego,amd64

package qsort

const purego = false
