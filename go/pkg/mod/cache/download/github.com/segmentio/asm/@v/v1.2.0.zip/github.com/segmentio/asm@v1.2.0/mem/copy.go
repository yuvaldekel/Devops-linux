package mem

func copyGeneric(dst, src []byte) int {
	return copy(dst, src)
}
