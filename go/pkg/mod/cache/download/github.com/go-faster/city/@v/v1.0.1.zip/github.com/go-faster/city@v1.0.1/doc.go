// Package city implements CityHash in go.
package city
