DROP TABLE IF EXISTS stdin_data;
CREATE TABLE stdin_data(name VARCHAR(64), id int);