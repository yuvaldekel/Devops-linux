DROP TABLE IF EXISTS csv_values;
CREATE TABLE csv_values (name varchar(64), id int);