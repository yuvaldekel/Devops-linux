## Usage

```shell script
# eg: ./errdoc-gen --source devel/pingap/tidb --module github.com/pingcap/tidb --output devel/pingap/tidb/errors.toml
./errdoc-gen --source /path/to/source/code --module ${module-name} --output /path/to/errors.toml
```