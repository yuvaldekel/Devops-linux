package constants

// Flags
const (
	QueryFlagParam          = "@param"
	QueryFlagSqlcVetDisable = "@sqlc-vet-disable"
)

// Rules
const (
	QueryRuleDbPrepare = "sqlc/db-prepare"
)
