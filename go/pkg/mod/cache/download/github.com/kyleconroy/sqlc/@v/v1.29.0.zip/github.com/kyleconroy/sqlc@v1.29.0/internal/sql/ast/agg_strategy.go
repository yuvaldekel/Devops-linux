package ast

type AggStrategy uint

func (n *AggStrategy) Pos() int {
	return 0
}
