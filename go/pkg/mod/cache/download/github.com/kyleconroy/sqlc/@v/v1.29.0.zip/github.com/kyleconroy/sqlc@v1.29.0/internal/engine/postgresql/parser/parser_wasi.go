//go:build windows || !cgo

package parser

import "github.com/wasilibs/go-pgquery/parser"

type Error = parser.Error
