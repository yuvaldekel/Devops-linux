//go:build !wasm

package cmd

import (
	_ "modernc.org/sqlite"
)
