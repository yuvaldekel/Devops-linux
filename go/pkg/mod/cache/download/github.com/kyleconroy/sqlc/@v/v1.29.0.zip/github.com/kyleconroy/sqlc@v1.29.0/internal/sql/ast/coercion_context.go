package ast

type CoercionContext uint

func (n *CoercionContext) Pos() int {
	return 0
}
