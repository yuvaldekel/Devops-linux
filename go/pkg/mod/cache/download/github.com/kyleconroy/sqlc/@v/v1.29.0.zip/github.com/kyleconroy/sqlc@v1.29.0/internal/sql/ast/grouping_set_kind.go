package ast

type GroupingSetKind uint

func (n *GroupingSetKind) Pos() int {
	return 0
}
