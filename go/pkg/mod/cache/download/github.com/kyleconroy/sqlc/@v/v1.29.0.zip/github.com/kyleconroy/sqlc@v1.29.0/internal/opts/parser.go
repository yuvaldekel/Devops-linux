package opts

type Parser struct {
	Debug Debug
}
