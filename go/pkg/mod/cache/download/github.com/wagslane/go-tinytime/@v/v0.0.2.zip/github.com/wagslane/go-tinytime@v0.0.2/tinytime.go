package tinytime

// TinyTime -
type TinyTime struct {
	unix uint32
}
