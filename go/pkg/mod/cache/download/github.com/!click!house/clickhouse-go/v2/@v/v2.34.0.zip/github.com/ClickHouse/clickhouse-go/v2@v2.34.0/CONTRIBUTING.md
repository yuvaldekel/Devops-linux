# Contributing notes

## Local setup

The easiest way to run tests is to use Docker Compose:

```
docker-compose up
make
```
