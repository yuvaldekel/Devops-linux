package proto

const (
	boolTrue  uint8 = 1
	boolFalse uint8 = 0
)
