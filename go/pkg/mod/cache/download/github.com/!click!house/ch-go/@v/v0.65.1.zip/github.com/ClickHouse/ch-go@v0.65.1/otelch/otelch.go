// Package otelch provide OpenTelemetry instrumentation for go-faster/ch.
package otelch

// Name of instrumentation.
const Name = "github.com/ClickHouse/ch-go"
