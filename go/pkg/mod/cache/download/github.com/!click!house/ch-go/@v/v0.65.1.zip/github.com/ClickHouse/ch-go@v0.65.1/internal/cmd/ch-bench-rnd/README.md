# Results


```
          String   2.908s   1.0 GB 344 MB/sec  28.66 million rows/sec
   Array(String)   1.452s   724 MB 499 MB/sec  19.13 million rows/sec
           UInt8    166ms   500 MB 3.0 GB/sec   3.01 billion rows/sec
         Float64    633ms   4.0 GB 6.3 GB/sec 789.69 million rows/sec
        DateTime    347ms   2.0 GB 5.8 GB/sec   1.44 billion rows/sec
          UInt64    629ms   4.0 GB 6.4 GB/sec 795.15 million rows/sec
   Array(UInt64)   1.824s    10 GB 5.5 GB/sec 274.18 million rows/sec
Nullable(UInt64)    903ms   4.5 GB 5.0 GB/sec 553.77 million rows/sec
            UUID   1.531s   8.0 GB 5.2 GB/sec 326.56 million rows/sec
```
