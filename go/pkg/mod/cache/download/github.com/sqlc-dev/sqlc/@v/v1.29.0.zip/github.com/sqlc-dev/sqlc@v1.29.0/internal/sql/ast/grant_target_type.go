package ast

type GrantTargetType uint

func (n *GrantTargetType) Pos() int {
	return 0
}
