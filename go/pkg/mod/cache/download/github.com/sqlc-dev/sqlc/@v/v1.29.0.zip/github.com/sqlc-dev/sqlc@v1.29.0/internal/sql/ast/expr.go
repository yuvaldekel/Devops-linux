package ast

type Expr struct {
}

func (n *Expr) Pos() int {
	return 0
}
