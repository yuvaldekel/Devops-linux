package wasm

type Runner struct {
	URL    string
	SHA256 string
	Env    []string
}
