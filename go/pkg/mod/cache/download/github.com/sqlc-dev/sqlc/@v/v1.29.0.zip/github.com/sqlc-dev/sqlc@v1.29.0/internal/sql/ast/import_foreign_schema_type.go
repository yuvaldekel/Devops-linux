package ast

type ImportForeignSchemaType uint

func (n *ImportForeignSchemaType) Pos() int {
	return 0
}
