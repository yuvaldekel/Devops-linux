package ast

type BoolTestType uint

func (n *BoolTestType) Pos() int {
	return 0
}
