package info

// When no version is set, return the next bug fix version
// after the most recent tag
const Version = "v1.29.0"
