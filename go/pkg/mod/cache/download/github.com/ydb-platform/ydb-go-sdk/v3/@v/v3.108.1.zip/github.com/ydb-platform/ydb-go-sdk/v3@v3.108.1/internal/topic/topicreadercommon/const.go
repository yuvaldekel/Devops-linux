package topicreadercommon

const DefaultBufferSize = 1024 * 1024
