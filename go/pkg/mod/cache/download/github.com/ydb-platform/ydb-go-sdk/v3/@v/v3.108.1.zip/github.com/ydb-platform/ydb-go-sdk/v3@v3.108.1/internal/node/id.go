package node

type ID interface {
	NodeID() uint32
}
