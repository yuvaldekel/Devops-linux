package rawtopicreader

// Check interface implementation
var _ TopicReaderStreamInterface = StreamReader{}
