CREATE TABLE emp (
    empname text,
    salary integer,
    last_date timestamp,
    last_user text
);