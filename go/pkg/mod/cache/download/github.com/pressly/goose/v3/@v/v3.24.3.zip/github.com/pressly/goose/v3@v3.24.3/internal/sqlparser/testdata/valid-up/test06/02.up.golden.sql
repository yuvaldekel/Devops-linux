INSERT INTO article (id, content) VALUES ('id_0001',  E'# My markdown doc

first paragraph

second paragraph');