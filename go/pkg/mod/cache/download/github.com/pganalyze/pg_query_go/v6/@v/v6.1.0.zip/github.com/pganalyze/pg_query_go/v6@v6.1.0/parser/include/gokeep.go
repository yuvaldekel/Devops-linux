//go:build required
// +build required

// package gokeep prevents go tooling from stripping the C dependencies.
package gokeep
