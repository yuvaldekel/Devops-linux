// Package parser includes the actual parsing logic using cgo to access libpg_query.
package parser
